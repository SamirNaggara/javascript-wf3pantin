document.addEventListener('DOMContentLoaded', function () {
     // Toutes nos inscructions serons ici pour être sur que le dom soit correctement chargé

     // Exerice : Quand on clique sur l'image, celle-ci tourne de 180 degré


     // Si je clique sur "Jonathan", il disparait

     // Si je clique sur une icone, elle grandit un peu et change de couleur

     // Toute les 5 secondes, "Jean Hervé" change de couleur
     // Si je clique dessus, l'effet s'arrete

     // Si je clique sur Developpeur Web et Web mobile, le texte change et devient "...et integrateur web !"

});