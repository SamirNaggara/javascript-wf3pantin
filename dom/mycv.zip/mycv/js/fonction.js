const CreateInput = (type, name, id, value, className, placeholder, required) => {
     const input = document.createElement('input');
     input.type = type;
     input.name = name;
     input.id = id;
     input.value = value;
     input.className = className;
     input.placeholder = placeholder;
     input.required = required;
     return input;

     // On test met les variables dans un tableau
     const fields = [type, name, id, value, className, placeholder, required];

     // On vérifie si les champs sont bien remplis
     for (let i = 0; i < fields.length; i++) {
          if (fields[i] === '') {
             console.log('Le champ ' + fields[i] + ' est vide');
             return false;
          } else {
             console.log('Le champ ' + fields[i] + ' est rempli');
             return true;
          }
     }

                     
  

}